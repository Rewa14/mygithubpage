//All
function Home() {
    window.location.href = 'index.html';
}

function Gallery() {
    window.location.href = 'Gallery.html';
}

function Tutorial() {
    window.location.href = 'Tutorial.html';
}

function Projects() {
    window.location.href = 'Projects.html';
}

//Header Size

//Gallery
loadBanner();

var index=0;
    function changeBanner(){ 
      [].forEach.call(document.getElementsByClassName("galleryImages"),function (v,i) { document.getElementsByClassName("galleryImages")[i].hidden = i!==index});
      index = (index+1) % document.getElementsByClassName("galleryImages").length;
      console.log("test");    
    }

function loadBanner() {
    var srcs = ["Images/P03-Marty2015.gif","Images/P05-Tardis.gif","Images/P41-ObiWanKenobi.gif","Images/P38-SorcererMickey.gif","Images/P12-IronMan.gif"];
    var c = 0;
    
    imgs = [];
    
    for(i = srcs.length - 1; i >= 0; i--) {
        imgs[i] = new Image();
        imgs[i].src = srcs[i];
        imgs[i].onload = function() {loaded();};
    }
    
    loaded = function() {
        c++;
        if(c === srcs.length){
            window.onload = function () {setInterval(changeBanner, 3000)};
            changeBanner();
        }
    };
    
    this.update = function() {};
}

function toggleMe(a) {
    var e = document.getElementById(a);
    if(!e) return true;
    if(e.style.display == "none") {
        e.style.display = "block";
    } else {
        e.style.display = "none";
    }
    return false;
}